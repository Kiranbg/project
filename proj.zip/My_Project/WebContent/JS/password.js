  $(function () {
        $("#btnVal").click(function () {
            var password = $("#password").val();
            var confirmPassword = $("#confirm").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });
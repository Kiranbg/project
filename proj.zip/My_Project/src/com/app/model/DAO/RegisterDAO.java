package com.app.model.DAO;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.DTO.RegisterDTO;
import com.app.controller.Registercontroller;

@Repository
public class RegisterDAO {
	@Autowired
	private SessionFactory factory;

	static final Logger LOGGER = Logger.getLogger(RegisterDAO.class);

	public void savedao(RegisterDTO dto) {
		LOGGER.info("inside dao");

		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.save(dto);
			transaction.commit();
		} catch (HibernateException he) {
			he.printStackTrace();
			transaction.rollback();
		} finally {
			session.close();
		}
	}

	public RegisterDTO loginDAOSave(RegisterDTO dto) {
		RegisterDTO fromdb = null;
		Session session = factory.openSession();
		Query query = session
				.createQuery("from com.app.DTO.RegisterDTO dt where dt.email=:email and dt.password=:password");
		try {
			query.setParameter("email", dto.getEmail());
			query.setParameter("password", dto.getPassword());
			fromdb = (RegisterDTO) query.uniqueResult();
			System.out.println(fromdb);
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return fromdb;
	}

	public RegisterDTO updateDAOSave(RegisterDTO dto) {
		Session session = factory.openSession();
		Query query = session.createQuery(
				"update com.app.DTO.RegisterDTO SET name=:name, phone=:phone, dob=:dob where email=:email");
		Transaction transaction = session.beginTransaction();
		int i = 0;
		try {
			query.setParameter("name", dto.getName());
			query.setParameter("dob", dto.getDob());
			query.setParameter("phone", dto.getPhone());
			query.setParameter("email", dto.getEmail());
			i = query.executeUpdate();
			LOGGER.debug(i);
			if (i == 1) {
				return dto;
			}
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

	public String forgotpasswordDAOSave(String email) {
		LOGGER.info("inside forgotpasswordDAOSave " + email);
		String password = null;
		Session session = factory.openSession();
		Query query = session.createQuery("from com.app.DTO.RegisterDTO dt where dt.email=:email");
		query.setParameter("email", email);
		RegisterDTO dto = (RegisterDTO) query.uniqueResult();
		LOGGER.info("DTO FROM DATA BASE" + dto);
		if (dto != null) {
			password = dto.getPassword();
			LOGGER.info("RETURNING PASSWORD " + password);
			return password;
		} else {
			return null;
		}
	}
}

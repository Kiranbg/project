package com.app.model.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.DTO.RegisterDTO;
import com.app.model.DAO.RegisterDAO;

@Service
public class Registerservice {
	@Autowired
	private RegisterDAO registerdao;

	@Autowired
	private RegisterDAO loginDAO;

	@Autowired
	private RegisterDAO updateDAO;

	@Autowired
	private RegisterDAO forgotpasswordDAO;

	static final Logger LOGGER = Logger.getLogger(Registerservice.class);

	public boolean saveregisterservlet(RegisterDTO dto) {
		LOGGER.info("inside service save method");
		if (dto != null && dto.getEmail() != null) {
			registerdao.savedao(dto);
			System.out.println("save is sucess");
			return true;
		} else {
			return false;
		}
	}

	public RegisterDTO loginServiceSave(RegisterDTO dto) {
		RegisterDTO fromdb = null;

		if (dto != null) {
			fromdb = loginDAO.loginDAOSave(dto);
		}
		return fromdb;
	}

	public RegisterDTO updateServiceSave(RegisterDTO dto) {
		RegisterDTO fromdb = null;

		if (dto != null) {
			fromdb = updateDAO.updateDAOSave(dto);
		}
		return fromdb;
	}

	public String forgotpasswordServiceSave(String email) {
		LOGGER.info("INSIDE forgotpasswordServiceSave" + email);
		String pass = null;
		if (email != null) {
			pass = forgotpasswordDAO.forgotpasswordDAOSave(email);
			LOGGER.info("INSIDE forgotpasswordServiceSave IF STATEMENT" + pass);
		}
		LOGGER.info("RETURNING :" + pass);
		return pass;
	}

}

package com.app.controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.http.HTTPBinding;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.DTO.RegisterDTO;
import com.app.model.service.Registerservice;

@Controller
@RequestMapping("/")
public class Registercontroller {
	@Autowired
	private Registerservice registerservlet;
	@Autowired
	private Registerservice loginService;
	@Autowired
	private Registerservice updateservice;
	@Autowired
	private Registerservice forgotpasswordservice;
	@Autowired
	private SendEmailController sendmail;
	@Autowired
	private JavaMailSender mailSender;

	static final Logger LOGGER = Logger.getLogger(Registercontroller.class);

	@RequestMapping(value = "/register.do", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView savecontroller(@ModelAttribute RegisterDTO dto) {
		boolean bool = false;
		LOGGER.info("inside save controller");
		bool = registerservlet.saveregisterservlet(dto);
		if (bool == true) {
			return new ModelAndView("Registersuccess.jsp", "name", dto.getName());
		} else {
			return new ModelAndView("register.jsp");
		}
	}

	@RequestMapping(value = "/loginform.do", method = { RequestMethod.GET, RequestMethod.POST })
	public String loginControllerSave(@ModelAttribute RegisterDTO dto, HttpServletRequest req) {
		HttpSession session = req.getSession(true);
		RegisterDTO fromdb = loginService.loginServiceSave(dto);
		if (fromdb != null) {
			session.setAttribute("dto", fromdb);
			return "welcome.jsp";
		} else {
			req.setAttribute("err", "Invalid UserId or Password");
			return "loginform.jsp";
		}
	}

	@RequestMapping(value = "/update.do", method = RequestMethod.POST)
	public String updateControllerSave(@ModelAttribute RegisterDTO dto, HttpServletRequest req) {
		HttpSession session = req.getSession(true);
		RegisterDTO fromdb = updateservice.updateServiceSave(dto);
		if (fromdb != null) {
			session.setAttribute("dto", fromdb);
			req.setAttribute("msg", "Updated successfully");
			return "welcome.jsp";
		} else {
			req.setAttribute("msg", "Not updated");
			return "update.jsp";
		}
	}

	@RequestMapping(value = "/forgotpassword.do", method = { RequestMethod.GET, RequestMethod.POST })
	public String forgotPasswordsave(HttpServletRequest request, HttpSession session, HttpServletResponse response) {
		String emailfromform = (String) request.getParameter("email").trim();
		String passwordFromDB = forgotpasswordservice.forgotpasswordServiceSave(emailfromform);
		if (passwordFromDB != null) {
			sendmail.doSendEmail(request);

			SimpleMailMessage details = new SimpleMailMessage();
			details.setTo(emailfromform);
			details.setSubject("From My App");
			details.setText("your password is " + passwordFromDB);

		//	request.setAttribute("pw", passwordFromDB);
			mailSender.send(details);
			request.setAttribute("password", "password has been sent to your mail id");
			return "/loginform.jsp";
		} else {
			request.setAttribute("password", "User not registered");
			return "/forgotpassword.jsp";
		}
	}
}

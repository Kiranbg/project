package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class SendEmailController {

	@Autowired
	private JavaMailSender mailSender;

	@SuppressWarnings("unused")
	@RequestMapping(value = "/EmailForm.do", method = RequestMethod.POST)
	public String doSendEmail(HttpServletRequest request) {
		// takes input from e-mail form
		String recipientAddress = "kiranbgkumar7@gmail.com";
		String subject = request.getParameter("subject");
		String message = request.getParameter("message");

		// creates a simple e-mail object
		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo("kiranbgkumar7@gmail.com");
		email.setSubject(subject);
		email.setText(message);

		if (recipientAddress != null) {
			// sends the e-mail
			mailSender.send(email);
			request.setAttribute("sent", "Thank you, your email has been sent");
			return "/welcome.jsp";
		} else {
			return "/Error.jsp";
		}
	}
}